<?
use PHPUnit\Framework\TestCase;

class RobotsTXTTest extends TestCase {}