<?
use PHPUnit\Framework\TestCase;

class DBTest extends TestCase {}