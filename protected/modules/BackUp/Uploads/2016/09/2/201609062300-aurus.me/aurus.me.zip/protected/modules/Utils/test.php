<?
use PHPUnit\Framework\TestCase;

class UtilsTest extends TestCase {}