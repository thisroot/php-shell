<li><a href="<?= APP::Module('Routing')->root ?>admin/backup/list">Manage</a></li>
<li><a href="<?= APP::Module('Routing')->root ?>admin/backup/settings">Settings</a></li>