-- MySQL dump 10.13  Distrib 5.7.14, for Linux (x86_64)
--
-- Host: localhost    Database: 
-- ------------------------------------------------------
-- Server version	5.7.14-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `shell`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `shell` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `shell`;

--
-- Table structure for table `backups`
--

DROP TABLE IF EXISTS `backups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `backups` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_user` int(11) DEFAULT NULL,
  `id_archive` varchar(255) DEFAULT NULL,
  `backup_path` varchar(255) DEFAULT NULL,
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backups`
--

LOCK TABLES `backups` WRITE;
/*!40000 ALTER TABLE `backups` DISABLE KEYS */;
/*!40000 ALTER TABLE `backups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `letters`
--

DROP TABLE IF EXISTS `letters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `letters` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `group_id` smallint(5) unsigned NOT NULL,
  `sender_id` smallint(5) unsigned NOT NULL,
  `subject` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `html` text COLLATE utf8_unicode_ci NOT NULL,
  `plaintext` text COLLATE utf8_unicode_ci NOT NULL,
  `list_id` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `up_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `group_id` (`group_id`,`sender_id`,`list_id`),
  KEY `group_id_2` (`group_id`),
  KEY `sender_id` (`sender_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `letters`
--

LOCK TABLES `letters` WRITE;
/*!40000 ALTER TABLE `letters` DISABLE KEYS */;
INSERT INTO `letters` VALUES (1,1,1,'Welcome','<h1>Welcome</h1>\n\nLogin page:\n<br>\n<a href=\"<?= APP::Module(\'Routing\')->root ?>login\"><?= APP::Module(\'Routing\')->root ?>login</a>\n<br>\n\n<h2>Login details</h2>\n<table border=\"0\" cellpadding=\"3\" width=\"300\">\n<tr>\n<td>E-Mail</td>\n<td><strong><?= $data[\'email\'] ?></strong></td>\n</tr>\n<tr>\n<td>Password</td>\n<td><strong><?= $data[\'password\'] ?></strong></td>\n</tr>\n</table>\n<br>\n\n<h2>Warning!</h2>\nYou must confirm your E-Mail address until <?= strftime(\'%e %B %Y\', $data[\'expire\']) ?>.\n<br>\nFollow the link to confirm your E-Mail address: <a href=\"<?= $data[\'link\'] ?>\" target=\"_blank\"><?= $data[\'link\'] ?></a>','Welcome\n\nLogin page\n--------------------\n<?= APP::Module(\'Routing\')->root ?>login\n\nLogin details\n--------------------\nE-Mail: <?= $data[\'email\'] ?>\nPassword: <?= $data[\'password\'] ?>\n\nWarning!\n--------------------\nYou must confirm your E-Mail address until <?= strftime(\'%e %B %Y\', $data[\'expire\']) ?>.\n\nFollow the link to confirm your E-Mail address:\n<?= $data[\'link\'] ?>','users','2016-09-06 19:38:38'),(2,1,1,'Reset password','<h1>Reset password</h1>\r\n\r\nFollow the link to set new password: <a href=\"<?= $data[\'link\'] ?>\" target=\"_blank\"><?= $data[\'link\'] ?></a>','Reset password\r\n\r\nFollow the link to set new password: <?= $data[\'link\'] ?>','users','2016-09-06 19:38:38'),(3,1,1,'Password successfully changed','<h1>Password successfully changed</h1>\r\n\r\nLogin page:\r\n<br>\r\n<a href=\"<?= APP::Module(\'Routing\')->root ?>login\"><?= APP::Module(\'Routing\')->root ?>login</a>\r\n<br>\r\n\r\n<h2>Login details</h2>\r\n<table border=\"0\" cellpadding=\"3\" width=\"300\">\r\n<tr>\r\n<td>E-Mail</td>\r\n<td><strong><?= $data[\'email\'] ?></strong></td>\r\n</tr>\r\n<tr>\r\n<td>Password</td>\r\n<td><strong><?= $data[\'password\'] ?></strong></td>\r\n</tr>\r\n</table>','Password successfully changed\r\n\r\nLogin page\r\n--------------------\r\n<?= APP::Module(\'Routing\')->root ?>login\r\n\r\nLogin details\r\n--------------------\r\nE-Mail: <?= $data[\'email\'] ?>\r\nPassword: <?= $data[\'password\'] ?>','users','2016-09-06 19:38:38'),(4,1,1,'Welcome','<h1>Welcome</h1>\r\n\r\nLogin page:\r\n<br>\r\n<a href=\"<?= APP::Module(\'Routing\')->root ?>login\"><?= APP::Module(\'Routing\')->root ?>login</a>\r\n<br>\r\n\r\n<h2>Login details</h2>\r\n<table border=\"0\" cellpadding=\"3\" width=\"300\">\r\n<tr>\r\n<td>E-Mail</td>\r\n<td><strong><?= $data[\'email\'] ?></strong></td>\r\n</tr>\r\n<tr>\r\n<td>Password</td>\r\n<td><strong><?= $data[\'password\'] ?></strong></td>\r\n</tr>\r\n</table>','Welcome\r\n\r\nLogin page\r\n--------------------\r\n<?= APP::Module(\'Routing\')->root ?>login\r\n\r\nLogin details\r\n--------------------\r\nE-Mail: <?= $data[\'email\'] ?>\r\nPassword: <?= $data[\'password\'] ?>','users','2016-09-06 19:38:38');
/*!40000 ALTER TABLE `letters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `letters_groups`
--

DROP TABLE IF EXISTS `letters_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `letters_groups` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `sub_id` smallint(5) NOT NULL DEFAULT '0',
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `up_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `sub_id` (`sub_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `letters_groups`
--

LOCK TABLES `letters_groups` WRITE;
/*!40000 ALTER TABLE `letters_groups` DISABLE KEYS */;
INSERT INTO `letters_groups` VALUES (0,0,'/','2016-09-06 19:38:18'),(1,0,'Users','2016-09-06 19:38:38');
/*!40000 ALTER TABLE `letters_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `registry`
--

DROP TABLE IF EXISTS `registry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `registry` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `sub_id` mediumint(5) unsigned NOT NULL,
  `item` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `value` text COLLATE utf8_unicode_ci NOT NULL,
  `up_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `group_id` (`item`)
) ENGINE=InnoDB AUTO_INCREMENT=125 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `registry`
--

LOCK TABLES `registry` WRITE;
/*!40000 ALTER TABLE `registry` DISABLE KEYS */;
INSERT INTO `registry` VALUES (1,0,'module_crypt_key','7b95e2904810a8c4a3d5d59020f4df96','2016-09-06 19:37:59'),(2,0,'module_trigger_type','[\"add_trigger\", \"Triggers\", \"Add trigger\"]','2016-09-06 19:37:59'),(3,0,'module_trigger_type','[\"remove_trigger\", \"Triggers\", \"Remove trigger\"]','2016-09-06 19:37:59'),(4,0,'module_trigger_type','[\"update_trigger\", \"Triggers\", \"Update trigger\"]','2016-09-06 19:37:59'),(5,0,'module_sessions_cookie_domain','aurus.me','2016-09-06 19:38:04'),(6,0,'module_sessions_cookie_lifetime','0','2016-09-06 19:38:04'),(7,0,'module_sessions_compress','9','2016-09-06 19:38:04'),(8,0,'module_sessions_gc_maxlifetime','1440','2016-09-06 19:38:04'),(9,0,'module_trigger_type','[\"update_sessions_settings\", \"Sessions\", \"Update settings\"]','2016-09-06 19:38:04'),(10,0,'module_mail_charset','UTF-8','2016-09-06 19:38:19'),(11,0,'module_mail_x_mailer','php-shell','2016-09-06 19:38:19'),(12,0,'module_trigger_type','[\"mail_add_letter\", \"Mail / Letters\", \"Add\"]','2016-09-06 19:38:19'),(13,0,'module_trigger_type','[\"mail_remove_letter\", \"Mail / Letters\", \"Remove\"]','2016-09-06 19:38:19'),(14,0,'module_trigger_type','[\"mail_update_letter\", \"Mail / Letters\", \"Update\"]','2016-09-06 19:38:19'),(15,0,'module_trigger_type','[\"mail_add_letters_group\", \"Mail / Letters\", \"Add group\"]','2016-09-06 19:38:19'),(16,0,'module_trigger_type','[\"mail_remove_letters_group\", \"Mail / Letters\", \"Remove group\"]','2016-09-06 19:38:19'),(17,0,'module_trigger_type','[\"mail_update_letters_group\", \"Mail / Letters\", \"Update group\"]','2016-09-06 19:38:19'),(18,0,'module_trigger_type','[\"mail_add_sender\", \"Mail / Senders\", \"Add\"]','2016-09-06 19:38:19'),(19,0,'module_trigger_type','[\"mail_remove_sender\", \"Mail / Senders\", \"Remove\"]','2016-09-06 19:38:19'),(20,0,'module_trigger_type','[\"mail_update_sender\", \"Mail / Senders\", \"Update\"]','2016-09-06 19:38:19'),(21,0,'module_trigger_type','[\"mail_add_senders_group\", \"Mail / Senders\", \"Add group\"]','2016-09-06 19:38:19'),(22,0,'module_trigger_type','[\"mail_remove_senders_group\", \"Mail / Senders\", \"Remove group\"]','2016-09-06 19:38:19'),(23,0,'module_trigger_type','[\"mail_update_senders_group\", \"Mail / Senders\", \"Update group\"]','2016-09-06 19:38:19'),(24,0,'module_trigger_type','[\"mail_update_settings\", \"Mail\", \"Update settings\"]','2016-09-06 19:38:19'),(25,0,'module_trigger_type','[\"mail_send_letter\", \"Mail\", \"Send mail\"]','2016-09-06 19:38:19'),(26,0,'module_users_register_activation_letter','1','2016-09-06 19:38:38'),(27,0,'module_users_reset_password_letter','2','2016-09-06 19:38:38'),(28,0,'module_users_change_password_letter','3','2016-09-06 19:38:38'),(29,0,'module_users_register_letter','4','2016-09-06 19:38:38'),(30,0,'module_users_role','default','2016-09-06 19:38:38'),(31,0,'module_users_role','new','2016-09-06 19:38:38'),(32,0,'module_users_role','user','2016-09-06 19:38:38'),(33,0,'module_users_role','admin','2016-09-06 19:38:38'),(34,30,'module_users_rule','[\"users\\\\/actions\\\\/change-password(.*)\",\"users\\/actions\\/login\"]','2016-09-06 19:38:38'),(35,30,'module_users_rule','[\"users\\\\/profile\",\"users\\/actions\\/login\"]','2016-09-06 19:38:38'),(36,30,'module_users_rule','[\"admin(.*)\",\"users\\/actions\\/login\"]','2016-09-06 19:38:38'),(37,31,'module_users_rule','[\"admin(.*)\",\"users\\/actions\\/login\"]','2016-09-06 19:38:38'),(38,32,'module_users_rule','[\"admin(.*)\",\"users\\/actions\\/login\"]','2016-09-06 19:38:38'),(39,0,'module_users_auth_token','1','2016-09-06 19:38:38'),(40,0,'module_users_change_password_service','1','2016-09-06 19:38:38'),(41,0,'module_users_check_rules','1','2016-09-06 19:38:38'),(42,0,'module_users_gen_pass_length','6','2016-09-06 19:38:38'),(43,0,'module_users_login_service','1','2016-09-06 19:38:38'),(44,0,'module_users_min_pass_length','3','2016-09-06 19:38:38'),(45,0,'module_users_register_service','1','2016-09-06 19:38:38'),(46,0,'module_users_reset_password_service','1','2016-09-06 19:38:38'),(47,0,'module_users_social_auth_fb_id','0','2016-09-06 19:38:38'),(48,0,'module_users_social_auth_fb_key','0','2016-09-06 19:38:38'),(49,0,'module_users_social_auth_google_id','0','2016-09-06 19:38:38'),(50,0,'module_users_social_auth_google_key','0','2016-09-06 19:38:38'),(51,0,'module_users_social_auth_vk_id','0','2016-09-06 19:38:38'),(52,0,'module_users_social_auth_vk_key','0','2016-09-06 19:38:38'),(53,0,'module_users_social_auth_ya_id','0','2016-09-06 19:38:38'),(54,0,'module_users_social_auth_ya_key','0','2016-09-06 19:38:38'),(55,0,'module_users_timeout_activation','3 days','2016-09-06 19:38:38'),(56,0,'module_users_timeout_email','1 year','2016-09-06 19:38:38'),(57,0,'module_users_timeout_token','1 year','2016-09-06 19:38:38'),(58,0,'module_trigger_type','[\"user_logout\", \"Users\", \"Logout\"]','2016-09-06 19:38:38'),(59,0,'module_trigger_type','[\"user_activate\", \"Users\", \"Activate\"]','2016-09-06 19:38:38'),(60,0,'module_trigger_type','[\"remove_user\", \"Users\", \"Remove\"]','2016-09-06 19:38:38'),(61,0,'module_trigger_type','[\"add_user\", \"Users\", \"Add\"]','2016-09-06 19:38:38'),(62,0,'module_trigger_type','[\"user_login\", \"Users\", \"Login\"]','2016-09-06 19:38:38'),(63,0,'module_trigger_type','[\"user_double_login\", \"Users\", \"Double login\"]','2016-09-06 19:38:38'),(64,0,'module_trigger_type','[\"register_user\", \"Users\", \"Register\"]','2016-09-06 19:38:38'),(65,0,'module_trigger_type','[\"reset_user_password\", \"Users\", \"Reset password\"]','2016-09-06 19:38:38'),(66,0,'module_trigger_type','[\"change_user_password\", \"Users\", \"Change password\"]','2016-09-06 19:38:38'),(67,0,'module_trigger_type','[\"update_user\", \"Users\", \"Update\"]','2016-09-06 19:38:38'),(68,0,'module_trigger_type','[\"add_user_role\", \"Users / Roles\", \"Add\"]','2016-09-06 19:38:38'),(69,0,'module_trigger_type','[\"remove_user_role\", \"Users / Roles\", \"Remove\"]','2016-09-06 19:38:38'),(70,0,'module_trigger_type','[\"add_user_rule\", \"Users / Rules\", \"Add\"]','2016-09-06 19:38:38'),(71,0,'module_trigger_type','[\"remove_user_rule\", \"Users / Rules\", \"Remove\"]','2016-09-06 19:38:38'),(72,0,'module_trigger_type','[\"update_user_rule\", \"Users / Rules\", \"Update\"]','2016-09-06 19:38:38'),(73,0,'module_trigger_type','[\"update_users_oauth_settings\", \"Users / Settings\", \"Update OAuth\"]','2016-09-06 19:38:38'),(74,0,'module_trigger_type','[\"update_users_notifications_settings\", \"Users / Settings\", \"Update notifications\"]','2016-09-06 19:38:38'),(75,0,'module_trigger_type','[\"update_users_services_settings\", \"Users / Settings\", \"Update services\"]','2016-09-06 19:38:38'),(76,0,'module_trigger_type','[\"update_users_auth_settings\", \"Users / Settings\", \"Update auth\"]','2016-09-06 19:38:38'),(77,0,'module_trigger_type','[\"update_users_passwords_settings\", \"Users / Settings\", \"Update passwords\"]','2016-09-06 19:38:38'),(78,0,'module_trigger_type','[\"update_users_timeouts_settings\", \"Users / Settings\", \"Update timeouts\"]','2016-09-06 19:38:38'),(79,0,'module_trigger_type','[\"import_locale_module\", \"Admin\", \"Import locale module\"]','2016-09-06 19:38:38'),(80,0,'module_trigger_type','[\"remove_imported_module\", \"Admin\", \"Remove imported module\"]','2016-09-06 19:38:38'),(81,0,'module_trigger_type','[\"export_module\", \"Admin\", \"Export module\"]','2016-09-06 19:38:38'),(82,0,'module_trigger_type','[\"uninstall_module\", \"Admin\", \"Uninstall module\"]','2016-09-06 19:38:38'),(83,0,'module_cache_memcache_host','127.0.0.1','2016-09-06 19:46:16'),(84,0,'module_cache_memcache_port','11211','2016-09-06 19:46:16'),(85,0,'module_trigger_type','[\"add_ssh_connection\", \"SSH\", \"Add connection\"]','2016-09-06 19:46:16'),(86,0,'module_trigger_type','[\"remove_ssh_connection\", \"SSH\", \"Remove connection\"]','2016-09-06 19:46:16'),(87,0,'module_trigger_type','[\"update_ssh_connection\", \"SSH\", \"Update connection\"]','2016-09-06 19:46:16'),(88,0,'module_cron_tmp_file','/tmp/crontab','2016-09-06 19:46:17'),(89,0,'module_trigger_type','[\"add_cron_job\", \"Cron\", \"Add job\"]','2016-09-06 19:46:18'),(90,0,'module_trigger_type','[\"update_cron_job\", \"Cron\", \"Update job\"]','2016-09-06 19:46:18'),(91,0,'module_trigger_type','[\"remove_cron_job\", \"Cron\", \"Remove job\"]','2016-09-06 19:46:18'),(92,0,'module_trigger_type','[\"update_cron_settings\", \"Cron\", \"Update settings\"]','2016-09-06 19:46:18'),(93,0,'module_trigger_type','[\"remove_log_file\", \"Logs\", \"Remove log file\"]','2016-09-06 19:46:18'),(94,0,'module_ssh_connection','[\"127.0.0.1\",\"325\",\"www-data\",\"PJK20EB8lS3AJ_WODzm7Ki1DmILSmSTSN-QpAm0n-e4\"]','2016-09-06 19:57:23'),(95,0,'module_taskmanager_db_connection','auto','2016-09-06 19:57:59'),(96,0,'module_taskmanager_complete_lifetime','1 month','2016-09-06 19:57:59'),(97,0,'module_taskmanager_max_execution_time','72000','2016-09-06 19:57:59'),(98,0,'module_taskmanager_memory_limit','512M','2016-09-06 19:57:59'),(99,0,'module_taskmanager_tmp_dir','/tmp','2016-09-06 19:57:59'),(100,94,'module_cron_job','*/1 * * * * php /var/www/adminus/data/www/aurus.me/phpshell/init.php TaskManager Exec','2016-09-06 19:57:59'),(101,94,'module_cron_job','*/1 * * * * php /var/www/adminus/data/www/aurus.me/phpshell/init.php TaskManager GC','2016-09-06 19:57:59'),(102,0,'module_trigger_type','[\"taskmanager_add\", \"Task Manager\", \"Add task\"]','2016-09-06 19:57:59'),(103,0,'module_trigger_type','[\"taskmanager_update\", \"Task Manager\", \"Update task\"]','2016-09-06 19:57:59'),(104,0,'module_trigger_type','[\"taskmanager_remove\", \"Task Manager\", \"Remove task\"]','2016-09-06 19:57:59'),(105,0,'module_trigger_type','[\"taskmanager_exec\", \"Task Manager\", \"Exec task\"]','2016-09-06 19:57:59'),(106,0,'module_trigger_type','[\"taskmanager_update_settings\", \"Task Manager\", \"Update settings\"]','2016-09-06 19:57:59'),(107,0,'module_backup_ssh_connection','94','2016-09-06 19:59:28'),(108,0,'module_backup_remote_host','nebesa.me','2016-09-06 19:59:28'),(109,0,'module_backup_remote_email','post@aurus.me','2016-09-06 19:59:28'),(110,0,'module_backup_remote_pass','QwHWr7m6s-9yB72ln9TzARWKw6dJn3-gkyJdLHftajU','2016-09-06 19:59:28'),(111,0,'module_backup_server_mode','0','2016-09-06 19:59:28'),(112,0,'module_backup_max_saved_backups','10','2016-09-06 19:59:28'),(113,0,'module_backup_segment_size','500','2016-09-06 19:59:28'),(114,94,'module_cron_job','0 0 * * * php /var/www/adminus/data/www/aurus.me/phpshell/init.php BackUp SendFile','2016-09-06 19:59:28'),(115,0,'module_backup_cron_id','[\"114\"]','2016-09-06 19:59:28'),(116,30,'module_users_rule','[\"backup\\\\/user(.*)\",\"users\\/login\"]','2016-09-06 19:59:28'),(117,0,'module_backup_users_rule','116','2016-09-06 19:59:28'),(118,0,'module_trigger_type','[\"send_backup\", \"BackUp\", \"SendFile\"]','2016-09-06 19:59:28'),(119,0,'module_trigger_type','[\"get_backup\", \"BackUp\", \"Make\"]','2016-09-06 19:59:28'),(120,0,'module_trigger_type','[\"server_get_backup\", \"BackUp\", \"GetFile\"]','2016-09-06 19:59:28'),(121,0,'module_trigger_type','[\"server_download_backup\", \"BackUp\", \"APIServerDownload\"]','2016-09-06 19:59:28'),(122,0,'module_trigger_type','[\"server_remove_backup\", \"BackUp\", \"APIServerRemove\"]','2016-09-06 19:59:28'),(123,0,'module_trigger_type','[\"get_backups_list\", \"BackUp\", \"APIClientList\"]','2016-09-06 19:59:28'),(124,0,'module_trigger_type','[\"server_get_backups_list\", \"BackUp\", \"APIServerList\"]','2016-09-06 19:59:28');
/*!40000 ALTER TABLE `registry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `senders`
--

DROP TABLE IF EXISTS `senders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `senders` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `group_id` smallint(5) unsigned NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `up_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `group_id` (`group_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `senders`
--

LOCK TABLES `senders` WRITE;
/*!40000 ALTER TABLE `senders` DISABLE KEYS */;
INSERT INTO `senders` VALUES (1,0,'Admin','post@aurus.me','2016-09-06 19:38:18');
/*!40000 ALTER TABLE `senders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `senders_groups`
--

DROP TABLE IF EXISTS `senders_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `senders_groups` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `sub_id` smallint(5) NOT NULL DEFAULT '0',
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `up_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `sub_id` (`sub_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `senders_groups`
--

LOCK TABLES `senders_groups` WRITE;
/*!40000 ALTER TABLE `senders_groups` DISABLE KEYS */;
INSERT INTO `senders_groups` VALUES (0,0,'/','2016-09-06 19:38:19');
/*!40000 ALTER TABLE `senders_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sessions` (
  `id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `touched` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `data` blob NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES ('23avchn98kkonetsbr56vv8604','2016-09-06 19:58:02','x\�-\��	�0\�]2�E�FZ\Z�)4\�I���\�;Jv�\"N\�r�j\�\�\��\�\�ZT�\r(\�]q7��xRY���8a\�\�o\��'),('7jubs8fgs05vlkiur00d9ejc84','2016-09-06 20:00:02','x\�-\��	�0\�]2�E�FZ\Z�)4\�I���\�;Jv�\"N\�r�j\�\�\��\�\�ZT�\r(\�]q7��xRY���8a\�\�o\��'),('836r6i26j1efn12s7vggml7kb3','2016-09-06 20:00:33','x\�}�AO\�0��\nʽ(MG��\�4\r. Ў���H\Z\'T�\�I\�\�H�,\�=[v^%�\���o�+`�t 6 �V�̲\��Ql�lgm\�9�\Z[Y\�\�S�\�]:]\�&3$�}��U�<\�\�}X;IM�];�O_7���Y�\�\�5\��\�N\�o_\"�=\��\�>_C\�\�t^�qT�\���oe\���\�!�\�\�f�\��i\�\�\�K\��kʧ�\�#��ʆ�aY~��Y\r'),('cvrk055u74es5k09ttsr1tf530','2016-09-06 19:59:01','x\�-\��	�0\�]2�E�FZ\Z�)4\�I���\�;Jv�\"N\�r�j\�\�\��\�\�ZT�\r(\�]q7��xRY���8a\�\�o\��'),('gbtclcjbriscnudllcrmn1ngk5','2016-09-06 19:58:02','x\�-\��	�0\�]2�E�FZ\Z�)4\�I���\�;Jv�\"N\�r�j\�\�\��\�\�ZT�\r(\�]q7��xRY���8a\�\�o\��'),('gp7v7um5ldq2tg595dqtl55sc1','2016-09-06 19:59:01','x\�-\��	�0\�]2�E�FZ\Z�)4\�I���\�;Jv�\"N\�r�j\�\�\��\�\�ZT�\r(\�]q7��xRY���8a\�\�o\��'),('o7c9doagugi2235uacajogqih2','2016-09-06 20:00:02','x\�-\��	�0\�]2�E�FZ\Z�)4\�I���\�;Jv�\"N\�r�j\�\�\��\�\�ZT�\r(\�]q7��xRY���8a\�\�o\��'),('rhjavdnguifan0mred9ju6nln5','2016-09-06 20:00:27','x\�}�AO!�����\Z���;{���\�E�\�qC+À�Z��k\�&$\�}ｙ��*YM?k<\� $ҁ��\�X���E\��(\�(ǡ.wnh\'��Y��\�)\�\�];]\�*3I4�0�9�8nva\�U\�\�n\�\�\�>��v��Pۡ���zؼEy|�+�[}\�&�3\�epЇ^\�8[u��Y-*\�VL\\q�\�*�\�bVR\���ox\�^~��iou/S|�n����Wt�&�\�\��\�]/');
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `social_accounts`
--

DROP TABLE IF EXISTS `social_accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `social_accounts` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `network` enum('vk','fb','google','ya') NOT NULL,
  `extra` varchar(250) NOT NULL,
  `up_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `social_accounts_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `social_accounts`
--

LOCK TABLES `social_accounts` WRITE;
/*!40000 ALTER TABLE `social_accounts` DISABLE KEYS */;
/*!40000 ALTER TABLE `social_accounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `task_manager`
--

DROP TABLE IF EXISTS `task_manager`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `task_manager` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `token` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `module` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `method` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `args` text COLLATE utf8_unicode_ci NOT NULL,
  `state` enum('wait','complete') COLLATE utf8_unicode_ci NOT NULL,
  `cr_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `exec_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `complete_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `token` (`token`),
  KEY `state` (`state`),
  KEY `state_2` (`state`,`exec_date`),
  KEY `token_2` (`token`,`state`,`exec_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `task_manager`
--

LOCK TABLES `task_manager` WRITE;
/*!40000 ALTER TABLE `task_manager` DISABLE KEYS */;
/*!40000 ALTER TABLE `task_manager` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `role` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `reg_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_visit` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `user_id` (`email`,`password`,`role`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'post@aurus.me','QwHWr7m6s-9yB72ln9TzARWKw6dJn3-gkyJdLHftajU','admin','2016-09-06 19:38:38','2016-09-06 19:38:38');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-09-06 23:00:34
