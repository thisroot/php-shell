<li><a href="<?= APP::Module('Routing')->root ?>admin/mail/letters/0">Letters</a></li>
<li><a href="<?= APP::Module('Routing')->root ?>admin/mail/senders/0">Senders</a></li>
<li><a href="<?= APP::Module('Routing')->root ?>admin/mail/settings">Settings</a></li>