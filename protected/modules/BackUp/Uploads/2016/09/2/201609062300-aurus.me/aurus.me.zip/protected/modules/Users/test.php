<?
use PHPUnit\Framework\TestCase;

class UsersTest extends TestCase {}