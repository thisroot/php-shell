<?
return [
    'init'  => true,
    'route' => 'robots.txt'
];