<?
use PHPUnit\Framework\TestCase;

class SessionsTest extends TestCase {}