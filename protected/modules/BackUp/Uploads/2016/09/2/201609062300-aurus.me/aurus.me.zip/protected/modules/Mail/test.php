<?
use PHPUnit\Framework\TestCase;

class MailTest extends TestCase {}