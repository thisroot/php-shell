<?php
use PHPUnit\Framework\TestCase;

class AdminTest extends TestCase {}