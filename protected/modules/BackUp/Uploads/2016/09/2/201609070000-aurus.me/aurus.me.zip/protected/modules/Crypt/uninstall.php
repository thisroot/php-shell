<?
APP::Module('Registry')->Delete([['item', '=', 'module_crypt_key', PDO::PARAM_STR]]);