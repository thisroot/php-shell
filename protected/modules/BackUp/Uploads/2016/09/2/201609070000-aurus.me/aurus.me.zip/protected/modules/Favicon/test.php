<?
use PHPUnit\Framework\TestCase;

class FaviconTest extends TestCase {}