<?
use PHPUnit\Framework\TestCase;

class RegistryTest extends TestCase {}