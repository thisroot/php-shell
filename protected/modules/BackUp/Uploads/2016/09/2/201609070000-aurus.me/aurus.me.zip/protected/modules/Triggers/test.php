<?
use PHPUnit\Framework\TestCase;

class TriggersTest extends TestCase {}