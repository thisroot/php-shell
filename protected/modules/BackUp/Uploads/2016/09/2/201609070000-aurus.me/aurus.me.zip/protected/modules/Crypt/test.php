<?
use PHPUnit\Framework\TestCase;

class CryptTest extends TestCase {}