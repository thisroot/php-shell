<footer id="footer">
    Copyright &copy; <?= date('Y') ?> php-shell

    <ul class="f-menu">
        <li><a href="https://php-shell.com">Home</a></li>
        <li><a href="https://php-shell.com/downloads">Downloads</a></li>
        <li><a href="https://php-shell.com/license">License</a></li>
    </ul>
</footer>