<a href="<?= APP::Module('Routing')->root ?>admin/mail/letters/0">Letters</a> &middot; 
<a href="<?= APP::Module('Routing')->root ?>admin/mail/senders/0">Senders</a> &middot; 
<a href="<?= APP::Module('Routing')->root ?>admin/mail/settings">Settings</a>