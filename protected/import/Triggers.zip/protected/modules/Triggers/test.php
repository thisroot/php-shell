<?
include_once 'init.php';
use PHPUnit\Framework\TestCase;

class TriggersTest extends TestCase {}