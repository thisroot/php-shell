<?
$data->extractTo(ROOT);

APP::Module('Triggers')->Register('remove_log_file', 'Logs', 'Remove log file');