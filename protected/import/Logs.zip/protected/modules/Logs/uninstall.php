<?
APP::Module('Triggers')->Unregister('remove_log_file');