<?
use PHPUnit\Framework\TestCase;

class CacheTest extends TestCase {}