<li><a href="<?= APP::Module('Routing')->root ?>admin/cron">Jobs</a></li>
<li><a href="<?= APP::Module('Routing')->root ?>admin/cron/settings">Settings</a></li>