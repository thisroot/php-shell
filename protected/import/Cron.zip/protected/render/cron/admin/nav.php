<a href="<?= APP::Module('Routing')->root ?>admin/cron">Jobs</a> &middot; 
<a href="<?= APP::Module('Routing')->root ?>admin/cron/settings">Settings</a>