<?
return [
    'connections' => [
        'auto' => [
            'type'      => 'mysql',
            'host'      => 'localhost',
            'database'  => 'phpshell',
            'username'  => 'root',
            'password'  => '',
            'charset'   => 'utf8'
        ]
    ],
    'init' => true
];
