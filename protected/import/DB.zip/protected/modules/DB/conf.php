<?
return [
    'connections' => [
        /*
        'auto' => [
            'type'      => 'mysql',
            'host'      => 'localhost',
            'database'  => '',
            'username'  => '',
            'password'  => '',
            'charset'   => 'utf8'
        ]
         */
    ],
    'init' => true
];
