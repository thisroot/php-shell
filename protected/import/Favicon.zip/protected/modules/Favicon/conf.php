<?
return [
    'init'      => true,
    'route'     => 'favicon.ico',
    'source'    => ROOT . '/protected/modules/Favicon/favicon.png'
];