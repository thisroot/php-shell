<?
return [
    'connection' => 'auto'
];