<li><a href="<?= APP::Module('Routing')->root ?>admin/users">Manage</a></li>
<li><a href="<?= APP::Module('Routing')->root ?>admin/users/roles">Roles</a></li>
<li><a href="<?= APP::Module('Routing')->root ?>admin/users/oauth/clients">OAuth clients</a></li>
<li><a href="<?= APP::Module('Routing')->root ?>admin/users/services">Services</a></li>
<li><a href="<?= APP::Module('Routing')->root ?>admin/users/auth">Authentication</a></li>
<li><a href="<?= APP::Module('Routing')->root ?>admin/users/passwords">Passwords</a></li>
<li><a href="<?= APP::Module('Routing')->root ?>admin/users/notifications">Notifications</a></li>
<li><a href="<?= APP::Module('Routing')->root ?>admin/users/timeouts">Timeouts</a></li>
<li><a href="<?= APP::Module('Routing')->root ?>admin/users/settings">Other</a></li>