<a href="<?= APP::Module('Routing')->root ?>admin/users">Users</a> &middot; 
<a href="<?= APP::Module('Routing')->root ?>admin/users/roles">Roles</a> &middot; 
<a href="<?= APP::Module('Routing')->root ?>admin/users/social">Social networks</a> &middot; 
<a href="<?= APP::Module('Routing')->root ?>admin/users/services">Services</a> &middot; 
<a href="<?= APP::Module('Routing')->root ?>admin/users/auth">Authentication</a> &middot; 
<a href="<?= APP::Module('Routing')->root ?>admin/users/passwords">Passwords</a> &middot; 
<a href="<?= APP::Module('Routing')->root ?>admin/users/notifications">Notifications</a> &middot; 
<a href="<?= APP::Module('Routing')->root ?>admin/users/timeouts">Timeouts</a>