<?
class Users {

    public $user = Array();
    
    function __construct($conf) {
        foreach ($conf['routes'] as $route) APP::Module('Routing')->Add($route[0], $route[1], $route[2]);
    }
    
    public function Init() {
        $this->user = &APP::Module('Sessions')->session['modules']['users']['user'];
        
        if (!isset(APP::Module('Sessions')->session['modules']['users']['double_auth'])) {
            APP::Module('Sessions')->session['modules']['users']['double_auth'] = false;
        }
        
        if (!$this->user) {
            $this->user['role'] = 'default';
        }

        if (isset($_COOKIE['modules']['users']['token'])) {
            if ($user = $this->Login($_COOKIE['modules']['users']['email'], $_COOKIE['modules']['users']['token'])) {
                $this->user = $this->Auth($user);
            }
        }
        
        if (((int) APP::Module('Registry')->Get('module_users_auth_token')) && ((int) APP::Module('Registry')->Get('module_users_login_service'))) {
            if (isset(APP::Module('Routing')->get['user_token'])) {
                $token = json_decode(APP::Module('Crypt')->Decode(APP::Module('Routing')->get['user_token']), 1);

                if ($user = $this->Login($token[0], $token[1])) {
                    $this->user = $this->Auth($user, true, true);
                }
            }
        }

        if ((int) APP::Module('Registry')->Get('module_users_check_rules')) {
            if ($target_uri = $this->CheckRules()) {
                $url = parse_url(APP::Module('Routing')->root . $target_uri);
                $target_query = ['return' => APP::Module('Crypt')->SafeB64Encode(APP::Module('Routing')->SelfUrl())];

                if (isset($url['query'])) {
                    foreach (explode('&', $url['query']) as $param) {
                        $param_data = explode('=', $param);
                        $target_query[$param_data[0]] = $param_data[1];
                    }
                }

                header('Location: ' . APP::Module('Routing')->root . $target_uri . '?' . http_build_query($target_query));
                exit;
            }
        }
        
    }

    public function Admin() {
        return APP::Render('users/admin/nav', 'content');
    }
    
    
    public function Login($email, $password) {
        return (int) APP::Module('DB')->Select(
            $this->conf['connection'], ['fetchColumn', 0], ['id'], 'users',
            [
                ['email', '=', $email, PDO::PARAM_STR],
                ['password', '=', $password, PDO::PARAM_STR]
            ]
        );
    }
    
    public function Register($email, $password, $role = 'new') {
        return APP::Module('DB')->Insert(
            $this->conf['connection'], 'users',
            Array(
                'id'            => 'NULL',
                'email'         => [$email, PDO::PARAM_STR],
                'password'      => [APP::Module('Crypt')->Encode($password), PDO::PARAM_STR],
                'role'          => [$role, PDO::PARAM_STR],
                'reg_date'      => 'NOW()',
                'last_visit'    => 'NOW()',
            )
        );
    }
    
    public function Auth($id, $set_cookie = true, $save_password = false) {
        $user = APP::Module('DB')->Select($this->conf['connection'], ['fetch', PDO::FETCH_ASSOC], ['*'], 'users', [['id', '=', $id, PDO::PARAM_INT]]);
        
        if ($set_cookie) {
            setcookie(
                'modules[users][email]', 
                $user['email'], 
                strtotime('+' . APP::Module('Registry')->Get('module_users_timeout_email')), 
                APP::$conf['location'][2],
                APP::$conf['location'][1]
            );

            setcookie(
                'modules[users][token]', 
                APP::Module('Crypt')->Encode($user['password']), 
                $save_password ? strtotime('+' . APP::Module('Registry')->Get('module_users_timeout_token')) : 0, 
                APP::$conf['location'][2], 
                APP::$conf['location'][1]
            );
        }
        
        return $user;
    }

    public function CheckRules() {
        $rules = [];

        foreach (APP::Module('Registry')->Get(['module_users_role'], ['id', 'value'])['module_users_role'] as $role) {
            $rule = (array) APP::Module('Registry')->Get(['module_users_rule'], 'value', $role['id']);
            $rules[$role['value']] = array_key_exists('module_users_rule', $rule) ? (array) $rule['module_users_rule'] : [];
        }

        if (array_key_exists($this->user['role'], $rules)) {
            foreach ($rules[$this->user['role']] as $rule) {
                $rule_data = json_decode($rule, 1);
                
                if (preg_match('/^' . preg_quote(APP::$conf['location'][2], '/') . $rule_data[0] . '$/', APP::Module('Routing')->RequestURI())) {
                    return $rule_data[1];
                }
            }
        }

        return false;
    }
    
    public function GeneratePassword($number) {
        $chars = [
            'a','b','c','d','e','f',
            'g','h','i','j','k','l',
            'm','n','o','p','r','s',
            't','u','v','x','y','z',
            'A','B','C','D','E','F',
            'G','H','I','J','K','L',
            'M','N','O','P','R','S',
            'T','U','V','X','Y','Z',

            '1','2','3','4','5','6',
            '7','8','9','0'

            /*
            '.',',',
            '(',')','[',']','!','?',
            '&','^','%','@','*','$',
            '<','>','/','|','+','-',
            '{','}','`','~'
            */
        ];

        $pass = '';
        
        for($i = 0; $i < $number; $i++) {
            $index = rand(0, count($chars) - 1);
            $pass .= $chars[$index];
        }
        
        return $pass;
    }
    
    
    public function ManageUsers() {
        APP::Render(
            'users/admin/index', 'include', 
            APP::Module('DB')->Select(
                $this->conf['connection'], ['fetchAll', PDO::FETCH_ASSOC], 
                ['id', 'email', 'password', 'role', 'reg_date', 'last_visit'], 'users'
            )
        );
    }
    
    public function AddUser() {
        APP::Render('users/admin/add', 'include', ['roles' => APP::Module('Registry')->Get(['module_users_role'])['module_users_role']]);
    }
    
    public function EditUser() {
        $user_id = APP::Module('Crypt')->Decode(APP::Module('Routing')->get['user_id_hash']);
        
        APP::Render(
            'users/admin/edit', 'include', 
            [
                'user' => APP::Module('DB')->Select(
                    $this->conf['connection'], ['fetch', PDO::FETCH_ASSOC], 
                    ['id', 'email', 'password', 'role', 'reg_date', 'last_visit'], 'users',
                    [['id', '=', $user_id, PDO::PARAM_INT]]
                ),
                'roles' => APP::Module('Registry')->Get(['module_users_role'])['module_users_role']
            ]
        );
    }
    
    public function LoginForm() {
        $return = isset(APP::Module('Routing')->get['return']) ? APP::Module('Crypt')->SafeB64Decode(APP::Module('Routing')->get['return']) : false;

        APP::Render(
            'users/login', 'include', 
            [
                'return' => $return ? filter_var($return, FILTER_VALIDATE_URL) ? $return : false : false,
                'social_networks' => APP::Module('Registry')->Get([
                    'module_users_social_auth_vk_id',
                    'module_users_social_auth_fb_id',
                    'module_users_social_auth_google_id',
                    'module_users_social_auth_ya_id'
                ])
            ]
        );
    }
    
    public function DoubleLoginForm() {
        $return = isset(APP::Module('Routing')->get['return_hash']) ? APP::Module('Crypt')->SafeB64Decode(APP::Module('Routing')->get['return_hash']) : false;

        APP::Render(
            'users/double_login', 'include', 
            [
                'return' => $return ? filter_var($return, FILTER_VALIDATE_URL) ? $return : false : false,
                'email' => $this->user['email']
            ]
        );
    }
    
    public function RegisterForm() {
        APP::Render(
            'users/register', 'include', 
            [
                'social_networks' => APP::Module('Registry')->Get([
                    'module_users_social_auth_vk_id',
                    'module_users_social_auth_fb_id',
                    'module_users_social_auth_google_id',
                    'module_users_social_auth_ya_id'
                ])
            ]
        );
    }

    public function ResetPasswordForm() {
        APP::Render('users/reset_password');
    }
    
    public function ChangePasswordForm() {
        APP::Render('users/change_password');
    }

    public function Activate() {
        $result = 'success';
        $user_id = APP::Module('Crypt')->Decode(APP::Module('Routing')->get['user_id_hash']);
        
        if (APP::Module('DB')->Select($this->conf['connection'], ['fetchColumn', 0], ['id'], 'users', [['id', '=', $user_id, PDO::PARAM_INT]])) {
            APP::Module('DB')->Update(
                $this->conf['connection'], 'users', 
                ['role' => 'user'], 
                [
                    ['id', '=', $user_id, PDO::PARAM_INT],
                    ['role', '!=', 'user', PDO::PARAM_STR]
                ]
            );
        } else {
            $result = 'error';
        }
        
        APP::Render('users/activate', 'include', $result);
    }
    
    public function Profile() {
        APP::Render(
            'users/profile', 'include', 
            [
                'social-profiles' => APP::Module('DB')->Select(
                    $this->conf['connection'], ['fetchAll', PDO::FETCH_ASSOC], 
                    ['network', 'extra'], 'social_accounts',
                    [['user_id', '=', $this->user['id'], PDO::PARAM_INT]]
                )
            ]
        );
    }
    
    public function ManageRoles() {
        APP::Render('users/admin/roles/index', 'include', APP::Module('Registry')->Get(['module_users_role'], ['id', 'value'])['module_users_role']);
    }
    
    public function AddRole() {
        APP::Render('users/admin/roles/add');
    }
    
    public function ManageRules() {
        $role_id = APP::Module('Crypt')->Decode(APP::Module('Routing')->get['role_id_hash']);
        $rules = APP::Module('Registry')->Get(['module_users_rule'], ['id', 'value'], $role_id);
        
        APP::Render('users/admin/roles/rules/index', 'include', [
            'role' => APP::Module('DB')->Select(
                APP::Module('Registry')->conf['connection'], ['fetchColumn', 0], 
                ['value'], 'registry',
                [['id', '=', $role_id, PDO::PARAM_INT]]
            ),
            'rules' => array_key_exists('module_users_rule', $rules) ? (array) $rules['module_users_rule'] : []
        ]);
    }
    
    public function AddRule() {
        $role_id = APP::Module('Crypt')->Decode(APP::Module('Routing')->get['role_id_hash']);
        
        APP::Render('users/admin/roles/rules/add', 'include', APP::Module('DB')->Select(
            APP::Module('Registry')->conf['connection'], ['fetchColumn', 0], 
            ['value'], 'registry',
            [['id', '=', $role_id, PDO::PARAM_INT]]
        ));
    }
    
    public function EditRule() {
        $role_id = APP::Module('Crypt')->Decode(APP::Module('Routing')->get['role_id_hash']);
        $rule_id = APP::Module('Crypt')->Decode(APP::Module('Routing')->get['rule_id_hash']);
        
        APP::Render('users/admin/roles/rules/edit', 'include', [
            'role' => APP::Module('DB')->Select(
                APP::Module('Registry')->conf['connection'], ['fetchColumn', 0], 
                ['value'], 'registry',
                [['id', '=', $role_id, PDO::PARAM_INT]]
            ),
            'rule' => json_decode(APP::Module('DB')->Select(
                APP::Module('Registry')->conf['connection'], ['fetchColumn', 0], 
                ['value'], 'registry',
                [['id', '=', $rule_id, PDO::PARAM_INT]]
            ), 1)
        ]);
    }
    
    public function SetupSocial() {
        $prefix = 'module_users_social_auth_';
        
        APP::Render(
            'users/admin/social', 'include', 
            APP::Module('Registry')->Get([
                $prefix . 'fb_id',
                $prefix . 'fb_key',
                $prefix . 'vk_id',
                $prefix . 'vk_key',
                $prefix . 'google_id',
                $prefix . 'google_key',
                $prefix . 'ya_id',
                $prefix . 'ya_key'
            ])
        );
    }
    
    public function SetupNotifications() {
        APP::Render(
            'users/admin/notifications', 'include', 
            APP::Module('Registry')->Get([
                'module_users_register_activation_letter',
                'module_users_reset_password_letter',
                'module_users_register_letter',
                'module_users_change_password_letter'
            ])
        );
    }
    
    public function SetupServices() {
        APP::Render(
            'users/admin/services', 'include', 
            APP::Module('Registry')->Get([
                'module_users_login_service',
                'module_users_register_service',
                'module_users_reset_password_service',
                'module_users_change_password_service'
            ])
        );
    }
    
    public function SetupAuth() {
        APP::Render(
            'users/admin/auth', 'include', 
            APP::Module('Registry')->Get([
                'module_users_check_rules',
                'module_users_auth_token'
            ])
        );
    }
    
    public function SetupPasswords() {
        APP::Render(
            'users/admin/passwords', 'include', 
            APP::Module('Registry')->Get([
                'module_users_min_pass_length',
                'module_users_gen_pass_length'
            ])
        );
    }
    
    public function SetupTimeouts() {
        APP::Render(
            'users/admin/timeouts', 'include', 
            APP::Module('Registry')->Get([
                'module_users_timeout_token',
                'module_users_timeout_email',
                'module_users_timeout_activation'
            ])
        );
    }
    
    
    public function APIRemoveUser() {
        $out = [
            'status' => 'success',
            'errors' => []
        ];

        if (!APP::Module('DB')->Select(
            $this->conf['connection'], ['fetchColumn', 0], 
            ['COUNT(id)'], 'users',
            [['id', '=', $_POST['id'], PDO::PARAM_INT]]
        )) {
            $out['status'] = 'error';
            $out['errors'][] = 1;
        }
        
        if ($out['status'] == 'success') {
            $out['count'] = APP::Module('DB')->Delete(
                $this->conf['connection'], 'users',
                [['id', '=', $_POST['id'], PDO::PARAM_INT]]
            );
        }

        header('Access-Control-Allow-Headers: X-Requested-With, Content-Type');
        header('Access-Control-Allow-Origin: ' . APP::$conf['location'][1]);
        header('Content-Type: application/json');
        
        echo json_encode($out);
        exit;
    }
    
    public function APIAddUser() {
        $out = [
            'status' => 'success',
            'errors' => []
        ];
        
        if (filter_var($_POST['email'], FILTER_VALIDATE_EMAIL) === false) {
            $out['status'] = 'error';
            $out['errors'][] = 1;
        } else if (APP::Module('DB')->Select($this->conf['connection'], ['fetchColumn', 0], ['id'], 'users', [['email', '=', $_POST['email'], PDO::PARAM_STR]])) {
            $out['status'] = 'error';
            $out['errors'][] = 2;
        }
        
        if (empty($_POST['password'])) {
            $out['status'] = 'error';
            $out['errors'][] = 3;
        } else if (strlen($_POST['password']) < (int) APP::Module('Registry')->Get('module_users_min_pass_length')) {
            $out['status'] = 'error';
            $out['errors'][] = 4;
        } else if ($_POST['password'] != $_POST['re-password']) {
            $out['status'] = 'error';
            $out['errors'][] = 5;
        }
        
        if ($out['status'] == 'success') {
            $user_id = $this->Register($_POST['email'], $_POST['password'], $_POST['role']);
            
            if ((int) $_POST['notification']) {
                $letter = APP::Module('DB')->Select(
                    APP::Module('Mail')->conf['connection'], 
                    ['fetch', PDO::FETCH_ASSOC], 
                    [
                        'letters.subject', 
                        'letters.html', 
                        'letters.plaintext', 
                        'letters.list_id',
                        'senders.name',
                        'senders.email'
                    ], 
                    'letters', 
                    [['letters.id', '=', $_POST['notification'], PDO::PARAM_INT]],
                    ['join/senders' => [['senders.id','=','letters.sender_id']]]
                );

                $login_details = [
                    'email' => $_POST['email'],
                    'password' => $_POST['password'],
                    'expire' => strtotime('+' . APP::Module('Registry')->Get('module_users_timeout_activation')),
                    'link' => APP::Module('Routing')->root . 'users/activate/' . APP::Module('Crypt')->Encode($user_id)
                ];

                APP::Module('Mail')->Send(
                    [$letter['email'], $letter['name']], $_POST['email'], $letter['subject'], 
                    [
                        APP::Render($letter['html'], 'eval', $login_details),
                        APP::Render($letter['plaintext'], 'eval', $login_details)
                    ],
                    ['List-id' => $letter['list_id']]
                );
            }
            
            $out['user_id'] = $user_id;
        }

        header('Access-Control-Allow-Headers: X-Requested-With, Content-Type');
        header('Access-Control-Allow-Origin: ' . APP::$conf['location'][1]);
        header('Content-Type: application/json');
        
        echo json_encode($out);
        exit;
    }
    
    public function APILogin() {
        $status = 'error';
        
        if (($user = $this->Login($_POST['email'], APP::Module('Crypt')->Encode($_POST['password']))) && ((int) APP::Module('Registry')->Get('module_users_login_service'))) {
            $this->user = $this->Auth($user, true, isset($_POST['remember-me']));
            $status = 'success';
        }
        
        header('Access-Control-Allow-Headers: X-Requested-With, Content-Type');
        header('Access-Control-Allow-Origin: ' . APP::$conf['location'][1]);
        header('Content-Type: application/json');
        
        echo json_encode(['status' => $status]);
        exit;
    }
    
    public function APIDoubleLogin() {
        $status = 'error';
        
        if ($this->user['password'] === APP::Module('Crypt')->Encode($_POST['password'])) {
            APP::Module('Sessions')->session['modules']['users']['double_auth'] = true;
            $status = 'success';
        }
        
        header('Access-Control-Allow-Headers: X-Requested-With, Content-Type');
        header('Access-Control-Allow-Origin: ' . APP::$conf['location'][1]);
        header('Content-Type: application/json');
        
        echo json_encode(['status' => $status]);
        exit;
    }
    
    public function APIRegister() {
        $out = [
            'status' => 'success',
            'errors' => []
        ];
        
        if (filter_var($_POST['email'], FILTER_VALIDATE_EMAIL) === false) {
            $out['status'] = 'error';
            $out['errors'][] = 1;
        } else if (APP::Module('DB')->Select($this->conf['connection'], ['fetchColumn', 0], ['id'], 'users', [['email', '=', $_POST['email'], PDO::PARAM_STR]])) {
            $out['status'] = 'error';
            $out['errors'][] = 2;
        }
        
        if (empty($_POST['password'])) {
            $out['status'] = 'error';
            $out['errors'][] = 3;
        } else if (strlen($_POST['password']) < (int) APP::Module('Registry')->Get('module_users_min_pass_length')) {
            $out['status'] = 'error';
            $out['errors'][] = 4;
        } else if ($_POST['password'] != $_POST['re-password']) {
            $out['status'] = 'error';
            $out['errors'][] = 5;
        }
        
        if (!(int) APP::Module('Registry')->Get('module_users_register_service')) {
            $out['status'] = 'error';
            $out['errors'][] = 6;
        }
        
        if ($out['status'] == 'success') {
            $user_id = $this->Register($_POST['email'], $_POST['password']);
            $this->user = $this->Auth($user_id, true, false);

            $letter = APP::Module('DB')->Select(
                APP::Module('Mail')->conf['connection'], 
                ['fetch', PDO::FETCH_ASSOC], 
                [
                    'letters.subject', 
                    'letters.html', 
                    'letters.plaintext', 
                    'letters.list_id',
                    'senders.name',
                    'senders.email'
                ], 
                'letters', 
                [['letters.id', '=', APP::Module('Registry')->Get('module_users_register_activation_letter'), PDO::PARAM_INT]],
                ['join/senders' => [['senders.id','=','letters.sender_id']]]
            );

            $login_details = [
                'email' => $_POST['email'],
                'password' => $_POST['password'],
                'expire' => strtotime('+' . APP::Module('Registry')->Get('module_users_timeout_activation')),
                'link' => APP::Module('Routing')->root . 'users/activate/' . APP::Module('Crypt')->Encode($user_id)
            ];
            
            APP::Module('Mail')->Send(
                [$letter['email'], $letter['name']], $_POST['email'], $letter['subject'], 
                [
                    APP::Render($letter['html'], 'eval', $login_details),
                    APP::Render($letter['plaintext'], 'eval', $login_details)
                ],
                ['List-id' => $letter['list_id']]
            );
            
            $out['user_id'] = $user_id;
        }

        header('Access-Control-Allow-Headers: X-Requested-With, Content-Type');
        header('Access-Control-Allow-Origin: ' . APP::$conf['location'][1]);
        header('Content-Type: application/json');
        
        echo json_encode($out);
        exit;
    }
    
    public function APIResetPassword() {
        $out = [
            'status' => 'success',
            'errors' => []
        ];

        if (filter_var($_POST['email'], FILTER_VALIDATE_EMAIL) === false) {
            $out['status'] = 'error';
            $out['errors'][] = 1;
        } else if (!APP::Module('DB')->Select($this->conf['connection'], ['fetchColumn', 0], ['id'], 'users', [['email', '=', $_POST['email'], PDO::PARAM_STR]])) {
            $out['status'] = 'error';
            $out['errors'][] = 2;
        }
        
        if (!(int) APP::Module('Registry')->Get('module_users_reset_password_service')) {
            $out['status'] = 'error';
            $out['errors'][] = 3;
        }
        
        if ($out['status'] == 'success') {
            $token = [
                $_POST['email'],
                APP::Module('DB')->Select($this->conf['connection'], ['fetchColumn', 0], ['password'], 'users', [['email', '=', $_POST['email'], PDO::PARAM_STR]])
            ];

            $letter = APP::Module('DB')->Select(
                APP::Module('Mail')->conf['connection'], 
                ['fetch', PDO::FETCH_ASSOC], 
                [
                    'letters.subject', 
                    'letters.html', 
                    'letters.plaintext', 
                    'letters.list_id',
                    'senders.name',
                    'senders.email'
                ], 
                'letters', 
                [['letters.id', '=', APP::Module('Registry')->Get('module_users_reset_password_letter'), PDO::PARAM_INT]],
                ['join/senders' => [['senders.id','=','letters.sender_id']]]
            );

            $reset_password_details = ['link' => APP::Module('Routing')->root . 'users/change-password?user_token=' . APP::Module('Crypt')->Encode(json_encode($token))];
            
            $out = APP::Module('Mail')->Send(
                [$letter['email'], $letter['name']], $_POST['email'], $letter['subject'], 
                [
                    APP::Render($letter['html'], 'eval', $reset_password_details),
                    APP::Render($letter['plaintext'], 'eval', $reset_password_details)
                ],
                ['List-id' => $letter['list_id']]
            );
        }

        header('Access-Control-Allow-Headers: X-Requested-With, Content-Type');
        header('Access-Control-Allow-Origin: ' . APP::$conf['location'][1]);
        header('Content-Type: application/json');
        
        echo json_encode($out);
        exit;
    }
    
    public function APIChangePassword() {
        $out = [
            'status' => 'success',
            'errors' => []
        ];

        if (empty($_POST['password'])) {
            $out['status'] = 'error';
            $out['errors'][] = 1;
        } else if (strlen($_POST['password']) < (int) APP::Module('Registry')->Get('module_users_min_pass_length')) {
            $out['status'] = 'error';
            $out['errors'][] = 2;
        } else if ($_POST['password'] != $_POST['re-password']) {
            $out['status'] = 'error';
            $out['errors'][] = 3;
        }
        
        if (!(int) APP::Module('Registry')->Get('module_users_change_password_service')) {
            $out['status'] = 'error';
            $out['errors'][] = 4;
        }

        if ($out['status'] == 'success') {
            APP::Module('DB')->Update(
                $this->conf['connection'], 'users', 
                ['password' => APP::Module('Crypt')->Encode($_POST['password'])], 
                [['id', '=', $this->user['id'], PDO::PARAM_INT]]
            );
            
            $this->user = $this->Auth($this->user['id'], true, true);

            $letter = APP::Module('DB')->Select(
                APP::Module('Mail')->conf['connection'], 
                ['fetch', PDO::FETCH_ASSOC], 
                [
                    'letters.subject', 
                    'letters.html', 
                    'letters.plaintext', 
                    'letters.list_id',
                    'senders.name',
                    'senders.email'
                ], 
                'letters', 
                [['letters.id', '=', APP::Module('Registry')->Get('module_users_change_password_letter'), PDO::PARAM_INT]],
                ['join/senders' => [['senders.id','=','letters.sender_id']]]
            );

            $change_password_details = [
                'email' => $this->user['email'],
                'password' => $_POST['password'],
            ];
            
            $out = APP::Module('Mail')->Send(
                [$letter['email'], $letter['name']], $this->user['email'], $letter['subject'], 
                [
                    APP::Render($letter['html'], 'eval', $change_password_details),
                    APP::Render($letter['plaintext'], 'eval', $change_password_details)
                ],
                ['List-id' => $letter['list_id']]
            );
        }

        header('Access-Control-Allow-Headers: X-Requested-With, Content-Type');
        header('Access-Control-Allow-Origin: ' . APP::$conf['location'][1]);
        header('Content-Type: application/json');
        
        echo json_encode($out);
        exit;
    }
    
    public function APILogout() {
        $this->user = false;

        if (isset(APP::Module('Routing')->get['account']) ? (bool) APP::Module('Routing')->get['account'] : false) {
            setcookie(
                'modules[users][email]', '', 
                strtotime('-' . APP::Module('Registry')->Get('module_users_timeout_email')), 
                APP::$conf['location'][2], APP::$conf['location'][1]
            );
        }
        
        setcookie(
            'modules[users][token]', '', 
            strtotime('-' . APP::Module('Registry')->Get('module_users_timeout_token')), 
            APP::$conf['location'][2], APP::$conf['location'][1]
        );
        
        header('Access-Control-Allow-Headers: X-Requested-With, Content-Type');
        header('Access-Control-Allow-Origin: ' . APP::$conf['location'][1]);
        header('Content-Type: application/json');
        
        echo json_encode(['result' => true]);
        exit;
    }
    
    public function APIUpdateUser() {
        $out = [
            'status' => 'success',
            'errors' => []
        ];
        
        $user_id = APP::Module('Crypt')->Decode($_POST['id']);

        if (!APP::Module('DB')->Select($this->conf['connection'], ['fetchColumn', 0], ['COUNT(id)'], 'users', [['id', '=', $user_id, PDO::PARAM_INT]])) {
            $out['status'] = 'error';
            $out['errors'][] = 1;
        }

        if (APP::Module('Sessions')->session['modules']['users']['double_auth']) {
            if (empty($_POST['password'])) {
                $out['status'] = 'error';
                $out['errors'][] = 2;
            } else if (strlen($_POST['password']) < (int) APP::Module('Registry')->Get('module_users_min_pass_length')) {
                $out['status'] = 'error';
                $out['errors'][] = 3;
            } else if ($_POST['password'] != $_POST['re-password']) {
                $out['status'] = 'error';
                $out['errors'][] = 4;
            }
        }
        
        if (array_search($_POST['role'], APP::Module('Registry')->Get(['module_users_role'])['module_users_role']) === false) {
            $out['status'] = 'error';
            $out['errors'][] = 5;
        }

        if ($out['status'] == 'success') {
            APP::Module('DB')->Update($this->conf['connection'], 'users', ['role' => $_POST['role']], [['id', '=', $user_id, PDO::PARAM_INT]]);
        
            if (APP::Module('Sessions')->session['modules']['users']['double_auth']) {
                APP::Module('DB')->Update($this->conf['connection'], 'users', ['password' => APP::Module('Crypt')->Encode($_POST['password'])], [['id', '=', $user_id, PDO::PARAM_INT]]);
            }
        }

        header('Access-Control-Allow-Headers: X-Requested-With, Content-Type');
        header('Access-Control-Allow-Origin: ' . APP::$conf['location'][1]);
        header('Content-Type: application/json');
        
        echo json_encode($out);
        exit;
    }
    
    public function APIAddRole() {
        $out = [
            'status' => 'success',
            'errors' => []
        ];

        if (empty($_POST['role'])) {
            $out['status'] = 'error';
            $out['errors'][] = 1;
        }
        
        if ($out['status'] == 'success') {
            $out['user_id'] = APP::Module('Registry')->Add('module_users_role', $_POST['role']);
        }

        header('Access-Control-Allow-Headers: X-Requested-With, Content-Type');
        header('Access-Control-Allow-Origin: ' . APP::$conf['location'][1]);
        header('Content-Type: application/json');
        
        echo json_encode($out);
        exit;
    }
    
    public function APIRemoveRole() {
        $out = [
            'status' => 'success',
            'errors' => []
        ];

        if (!APP::Module('DB')->Select(
            APP::Module('Registry')->conf['connection'], ['fetchColumn', 0], 
            ['COUNT(id)'], 'registry',
            [['id', '=', $_POST['id'], PDO::PARAM_INT]]
        )) {
            $out['status'] = 'error';
            $out['errors'][] = 1;
        }
        
        if ($out['status'] == 'success') {
            $out['count'] = APP::Module('Registry')->Delete([['id', '=', $_POST['id'], PDO::PARAM_INT]]);
            $out['count'] = APP::Module('Registry')->Delete([['sub_id', '=', $_POST['id'], PDO::PARAM_INT]]);
        }

        header('Access-Control-Allow-Headers: X-Requested-With, Content-Type');
        header('Access-Control-Allow-Origin: ' . APP::$conf['location'][1]);
        header('Content-Type: application/json');
        
        echo json_encode($out);
        exit;
    }
    
    public function APIAddRule() {
        $out = [
            'status' => 'success',
            'errors' => []
        ];
        
        $role_id = APP::Module('Crypt')->Decode($_POST['role']);

        if (!APP::Module('DB')->Select(
            APP::Module('Registry')->conf['connection'], ['fetchColumn', 0], 
            ['COUNT(id)'], 'registry',
            [['id', '=', $role_id, PDO::PARAM_INT]]
        )) {
            $out['status'] = 'error';
            $out['errors'][] = 1;
        }
        
        if (empty($_POST['uri_pattern'])) {
            $out['status'] = 'error';
            $out['errors'][] = 2;
        }
        
        if (empty($_POST['target'])) {
            $out['status'] = 'error';
            $out['errors'][] = 3;
        }
        
        if ($out['status'] == 'success') {
            $out['rule_id'] = APP::Module('Registry')->Add('module_users_rule', json_encode([$_POST['uri_pattern'], $_POST['target']]), $role_id);
        }

        header('Access-Control-Allow-Headers: X-Requested-With, Content-Type');
        header('Access-Control-Allow-Origin: ' . APP::$conf['location'][1]);
        header('Content-Type: application/json');
        
        echo json_encode($out);
        exit;
    }
    
    public function APIRemoveRule() {
        $out = [
            'status' => 'success',
            'errors' => []
        ];

        if (!APP::Module('DB')->Select(
            APP::Module('Registry')->conf['connection'], ['fetchColumn', 0], 
            ['COUNT(id)'], 'registry',
            [['id', '=', $_POST['id'], PDO::PARAM_INT]]
        )) {
            $out['status'] = 'error';
            $out['errors'][] = 1;
        }
        
        if ($out['status'] == 'success') {
            $out['count'] = APP::Module('Registry')->Delete([['id', '=', $_POST['id'], PDO::PARAM_INT]]);
        }

        header('Access-Control-Allow-Headers: X-Requested-With, Content-Type');
        header('Access-Control-Allow-Origin: ' . APP::$conf['location'][1]);
        header('Content-Type: application/json');
        
        echo json_encode($out);
        exit;
    }
    
    public function APIUpdateRule() {
        $out = [
            'status' => 'success',
            'errors' => []
        ];
        
        $rule_id = APP::Module('Crypt')->Decode($_POST['rule']);

        if (!APP::Module('DB')->Select(
            APP::Module('Registry')->conf['connection'], ['fetchColumn', 0], 
            ['COUNT(id)'], 'registry',
            [['id', '=', $rule_id, PDO::PARAM_INT]]
        )) {
            $out['status'] = 'error';
            $out['errors'][] = 1;
        }
        
        if (empty($_POST['uri_pattern'])) {
            $out['status'] = 'error';
            $out['errors'][] = 2;
        }
        
        if (empty($_POST['target'])) {
            $out['status'] = 'error';
            $out['errors'][] = 3;
        }
        
        if ($out['status'] == 'success') {
            $out['rule_id'] = APP::Module('Registry')->Update(['value' => json_encode([$_POST['uri_pattern'], $_POST['target']])], [['id', '=', $rule_id, PDO::PARAM_INT]]);
        }

        header('Access-Control-Allow-Headers: X-Requested-With, Content-Type');
        header('Access-Control-Allow-Origin: ' . APP::$conf['location'][1]);
        header('Content-Type: application/json');
        
        echo json_encode($out);
        exit;
    }
    
    public function APIUpdateSocialSettings() {
        APP::Module('Registry')->Update(['value' => $_POST['module_users_social_auth_fb_id']], [['item', '=', 'module_users_social_auth_fb_id', PDO::PARAM_STR]]);
        APP::Module('Registry')->Update(['value' => $_POST['module_users_social_auth_fb_key']], [['item', '=', 'module_users_social_auth_fb_key', PDO::PARAM_STR]]);
        APP::Module('Registry')->Update(['value' => $_POST['module_users_social_auth_vk_id']], [['item', '=', 'module_users_social_auth_vk_id', PDO::PARAM_STR]]);
        APP::Module('Registry')->Update(['value' => $_POST['module_users_social_auth_vk_key']], [['item', '=', 'module_users_social_auth_vk_key', PDO::PARAM_STR]]);
        APP::Module('Registry')->Update(['value' => $_POST['module_users_social_auth_google_id']], [['item', '=', 'module_users_social_auth_google_id', PDO::PARAM_STR]]);
        APP::Module('Registry')->Update(['value' => $_POST['module_users_social_auth_google_key']], [['item', '=', 'module_users_social_auth_google_key', PDO::PARAM_STR]]);
        APP::Module('Registry')->Update(['value' => $_POST['module_users_social_auth_ya_id']], [['item', '=', 'module_users_social_auth_ya_id', PDO::PARAM_STR]]);
        APP::Module('Registry')->Update(['value' => $_POST['module_users_social_auth_ya_key']], [['item', '=', 'module_users_social_auth_ya_key', PDO::PARAM_STR]]);

        header('Access-Control-Allow-Headers: X-Requested-With, Content-Type');
        header('Access-Control-Allow-Origin: ' . APP::$conf['location'][1]);
        header('Content-Type: application/json');
        
        echo json_encode([
            'status' => 'success',
            'errors' => []
        ]);
        exit;
    }
    
    public function APIUpdateNotificationsSettings() {
        APP::Module('Registry')->Update(['value' => $_POST['module_users_register_activation_letter']], [['item', '=', 'module_users_register_activation_letter', PDO::PARAM_STR]]);
        APP::Module('Registry')->Update(['value' => $_POST['module_users_reset_password_letter']], [['item', '=', 'module_users_reset_password_letter', PDO::PARAM_STR]]);
        APP::Module('Registry')->Update(['value' => $_POST['module_users_register_letter']], [['item', '=', 'module_users_register_letter', PDO::PARAM_STR]]);
        APP::Module('Registry')->Update(['value' => $_POST['module_users_change_password_letter']], [['item', '=', 'module_users_change_password_letter', PDO::PARAM_STR]]);
        
        header('Access-Control-Allow-Headers: X-Requested-With, Content-Type');
        header('Access-Control-Allow-Origin: ' . APP::$conf['location'][1]);
        header('Content-Type: application/json');
        
        echo json_encode([
            'status' => 'success',
            'errors' => []
        ]);
        exit;
    }
    
    public function APIUpdateServicesSettings() {
        APP::Module('Registry')->Update(['value' => $_POST['module_users_login_service']], [['item', '=', 'module_users_login_service', PDO::PARAM_STR]]);
        APP::Module('Registry')->Update(['value' => $_POST['module_users_register_service']], [['item', '=', 'module_users_register_service', PDO::PARAM_STR]]);
        APP::Module('Registry')->Update(['value' => $_POST['module_users_reset_password_service']], [['item', '=', 'module_users_reset_password_service', PDO::PARAM_STR]]);
        APP::Module('Registry')->Update(['value' => $_POST['module_users_change_password_service']], [['item', '=', 'module_users_change_password_service', PDO::PARAM_STR]]);
        
        header('Access-Control-Allow-Headers: X-Requested-With, Content-Type');
        header('Access-Control-Allow-Origin: ' . APP::$conf['location'][1]);
        header('Content-Type: application/json');
        
        echo json_encode([
            'status' => 'success',
            'errors' => []
        ]);
        exit;
    }
    
    public function APIUpdateAuthSettings() {
        APP::Module('Registry')->Update(['value' => $_POST['module_users_check_rules']], [['item', '=', 'module_users_check_rules', PDO::PARAM_STR]]);
        APP::Module('Registry')->Update(['value' => $_POST['module_users_auth_token']], [['item', '=', 'module_users_auth_token', PDO::PARAM_STR]]);

        header('Access-Control-Allow-Headers: X-Requested-With, Content-Type');
        header('Access-Control-Allow-Origin: ' . APP::$conf['location'][1]);
        header('Content-Type: application/json');
        
        echo json_encode([
            'status' => 'success',
            'errors' => []
        ]);
        exit;
    }
    
    public function APIUpdatePasswordsSettings() {
        APP::Module('Registry')->Update(['value' => $_POST['module_users_min_pass_length']], [['item', '=', 'module_users_min_pass_length', PDO::PARAM_STR]]);
        APP::Module('Registry')->Update(['value' => $_POST['module_users_gen_pass_length']], [['item', '=', 'module_users_gen_pass_length', PDO::PARAM_STR]]);

        header('Access-Control-Allow-Headers: X-Requested-With, Content-Type');
        header('Access-Control-Allow-Origin: ' . APP::$conf['location'][1]);
        header('Content-Type: application/json');
        
        echo json_encode([
            'status' => 'success',
            'errors' => []
        ]);
        exit;
    }
    
    public function APIUpdateTimeoutsSettings() {
        APP::Module('Registry')->Update(['value' => $_POST['module_users_timeout_token']], [['item', '=', 'module_users_timeout_token', PDO::PARAM_STR]]);
        APP::Module('Registry')->Update(['value' => $_POST['module_users_timeout_email']], [['item', '=', 'module_users_timeout_email', PDO::PARAM_STR]]);
        APP::Module('Registry')->Update(['value' => $_POST['module_users_timeout_activation']], [['item', '=', 'module_users_timeout_activation', PDO::PARAM_STR]]);

        header('Access-Control-Allow-Headers: X-Requested-With, Content-Type');
        header('Access-Control-Allow-Origin: ' . APP::$conf['location'][1]);
        header('Content-Type: application/json');
        
        echo json_encode([
            'status' => 'success',
            'errors' => []
        ]);
        exit;
    }

    
    public function LoginVK() {
        if (!(int) APP::Module('Registry')->Get('module_users_login_service')) APP::Render('users/errors', 'include', 'auth_service');
        
        if (isset(APP::Module('Routing')->get['code'])) {
            $vk_auth = APP::Module('Registry')->Get([
                'module_users_social_auth_vk_id',
                'module_users_social_auth_vk_key'
            ]);

            $vk_result = json_decode(file_get_contents('https://oauth.vk.com/access_token?' . urldecode(http_build_query(['client_id' => $vk_auth['module_users_social_auth_vk_id'], 'client_secret' => $vk_auth['module_users_social_auth_vk_key'], 'code' => APP::Module('Routing')->get['code'], 'redirect_uri' => APP::Module('Routing')->root . 'users/login/vk']))), true);

            if (isset($vk_result['user_id'])) {
                if ($user_id = APP::Module('DB')->Select(
                        $this->conf['connection'], ['fetchColumn', 0], 
                        ['user_id'], 'social_accounts', 
                        [
                            ['network', '=', 'vk', PDO::PARAM_STR], 
                            ['extra', '=', $vk_result['user_id'], PDO::PARAM_STR]
                        ]
                )) {
                    $this->user = $this->Auth($user_id, true, true);
                } else {
                    if (isset($vk_result['email'])) {
                        if ($user_id = APP::Module('DB')->Select(
                                $this->conf['connection'], ['fetchColumn', 0], 
                                ['id'], 'users', [['email', '=', $vk_result['email'], PDO::PARAM_STR]]
                        )) {
                            APP::Module('DB')->Insert(
                                $this->conf['connection'], ' social_accounts',
                                [
                                    'id' => 'NULL',
                                    'user_id' => [$user_id, PDO::PARAM_INT],
                                    'network' => '"vk"',
                                    'extra' => [$vk_result['user_id'], PDO::PARAM_STR],
                                    'up_date' => 'NOW()',
                                ]
                            );
                            
                            $this->user = $this->Auth($user_id, true, true);
                        } else {
                            $password = $this->GeneratePassword((int) APP::Module('Registry')->Get('module_users_gen_pass_length'));
                            $user_id = $this->Register($vk_result['email'], $password, 'user');
                            $this->user = $this->Auth($user_id, true, true);
                            
                            APP::Module('DB')->Insert(
                                $this->conf['connection'], ' social_accounts',
                                [
                                    'id' => 'NULL',
                                    'user_id' => [$user_id, PDO::PARAM_INT],
                                    'network' => '"vk"',
                                    'extra' => [$vk_result['user_id'], PDO::PARAM_STR],
                                    'up_date' => 'NOW()',
                                ]
                            );
                            
                            $letter = APP::Module('DB')->Select(
                                APP::Module('Mail')->conf['connection'], 
                                ['fetch', PDO::FETCH_ASSOC], 
                                [
                                    'letters.subject', 
                                    'letters.html', 
                                    'letters.plaintext', 
                                    'letters.list_id',
                                    'senders.name',
                                    'senders.email'
                                ], 
                                'letters', 
                                [['letters.id', '=', APP::Module('Registry')->Get('module_users_register_letter'), PDO::PARAM_INT]],
                                ['join/senders' => [['senders.id','=','letters.sender_id']]]
                            );

                            $login_details = [
                                'email' => $vk_result['email'],
                                'password' => $password,
                            ];

                            APP::Module('Mail')->Send(
                                [$letter['email'], $letter['name']], $vk_result['email'], $letter['subject'], 
                                [
                                    APP::Render($letter['html'], 'eval', $login_details),
                                    APP::Render($letter['plaintext'], 'eval', $login_details)
                                ],
                                ['List-id' => $letter['list_id']]
                            );
                        }
                    } else {
                        APP::Render('users/errors', 'include', 'auth_vk_email');
                    }
                }
            } else {
                APP::Render('users/errors', 'include', 'auth_vk_user_id');
            }
            
            header('Location: ' . APP::Module('Crypt')->Decode(json_decode(APP::Module('Crypt')->SafeB64Decode(APP::Module('Routing')->get['state']), 1)['return']));
            exit;

            /*
            if (isset($token['access_token'])) {
                $params = array(
                    'uids'         => $token['user_id'],
                    'fields'       => 'uid,first_name,last_name,screen_name,sex,bdate,photo_big',
                    'access_token' => $token['access_token']
                );
                
                $userInfo = json_decode(file_get_contents('https://api.vk.com/method/users.get?' . urldecode(http_build_query($params))), true);
                
                ?><pre><? print_r($userInfo); ?></pre><?
            } else {
                // ошибка
            }
             * 
             */
        } else {
            APP::Render('users/errors', 'include', 'auth_vk_code');
        }
    }
    
    public function LoginFB() {
        if (!(int) APP::Module('Registry')->Get('module_users_login_service')) APP::Render('users/errors', 'include', 'auth_service');
        
        if (isset(APP::Module('Routing')->get['code'])) {
            $fb_auth = APP::Module('Registry')->Get([
                'module_users_social_auth_fb_id',
                'module_users_social_auth_fb_key'
            ]);

            $fb_result = null;
            
            parse_str(file_get_contents('https://graph.facebook.com/oauth/access_token?' . urldecode(http_build_query(['client_id' => $fb_auth['module_users_social_auth_fb_id'], 'client_secret' => $fb_auth['module_users_social_auth_fb_key'], 'code' => APP::Module('Routing')->get['code'], 'redirect_uri' => APP::Module('Routing')->root . 'users/login/fb']))), $fb_result);

            if (count($fb_result) > 0 && isset($fb_result['access_token'])) {
                $fb_user = json_decode(file_get_contents('https://graph.facebook.com/me?fields=email&' . urldecode(http_build_query(array('access_token' => $fb_result['access_token'])))), true);
                
                if (isset($fb_user['id'])) {
                    if ($user_id = APP::Module('DB')->Select(
                        $this->conf['connection'], ['fetchColumn', 0], 
                        ['user_id'], 'social_accounts', 
                        [
                            ['network', '=', 'fb', PDO::PARAM_STR], 
                            ['extra', '=', $fb_user['id'], PDO::PARAM_STR]
                        ]
                    )) {
                        $this->user = $this->Auth($user_id, true, true);
                    } else {
                        if (isset($fb_user['email'])) {
                            if ($user_id = APP::Module('DB')->Select(
                                $this->conf['connection'], ['fetchColumn', 0], 
                                ['id'], 'users', [['email', '=', $fb_user['email'], PDO::PARAM_STR]]
                            )) {
                                APP::Module('DB')->Insert(
                                    $this->conf['connection'], ' social_accounts',
                                    [
                                        'id' => 'NULL',
                                        'user_id' => [$user_id, PDO::PARAM_INT],
                                        'network' => '"fb"',
                                        'extra' => [$fb_user['id'], PDO::PARAM_STR],
                                        'up_date' => 'NOW()',
                                    ]
                                );

                                $this->user = $this->Auth($user_id, true, true);
                            } else {
                                $password = $this->GeneratePassword((int) APP::Module('Registry')->Get('module_users_gen_pass_length'));
                                $user_id = $this->Register($fb_user['email'], $password, 'user');
                                $this->user = $this->Auth($user_id, true, true);

                                APP::Module('DB')->Insert(
                                    $this->conf['connection'], ' social_accounts',
                                    [
                                        'id' => 'NULL',
                                        'user_id' => [$user_id, PDO::PARAM_INT],
                                        'network' => '"fb"',
                                        'extra' => [$fb_user['id'], PDO::PARAM_STR],
                                        'up_date' => 'NOW()',
                                    ]
                                );

                                $letter = APP::Module('DB')->Select(
                                    APP::Module('Mail')->conf['connection'], 
                                    ['fetch', PDO::FETCH_ASSOC], 
                                    [
                                        'letters.subject', 
                                        'letters.html', 
                                        'letters.plaintext', 
                                        'letters.list_id',
                                        'senders.name',
                                        'senders.email'
                                    ], 
                                    'letters', 
                                    [['letters.id', '=', APP::Module('Registry')->Get('module_users_register_letter'), PDO::PARAM_INT]],
                                    ['join/senders' => [['senders.id','=','letters.sender_id']]]
                                );

                                $login_details = [
                                    'email' => $fb_user['email'],
                                    'password' => $password,
                                ];

                                APP::Module('Mail')->Send(
                                    [$letter['email'], $letter['name']], $fb_user['email'], $letter['subject'], 
                                    [
                                        APP::Render($letter['html'], 'eval', $login_details),
                                        APP::Render($letter['plaintext'], 'eval', $login_details)
                                    ],
                                    ['List-id' => $letter['list_id']]
                                );
                            }
                        } else {
                            APP::Render('users/errors', 'include', 'auth_fb_email');
                        }
                    }
                } else {
                    APP::Render('users/errors', 'include', 'auth_fb_id');
                }

                header('Location: ' . APP::Module('Crypt')->Decode(json_decode(APP::Module('Crypt')->SafeB64Decode(APP::Module('Routing')->get['state']), 1)['return']));
                exit;
            } else {
                APP::Render('users/errors', 'include', 'auth_fb_access_token');
            }
        } else {
            APP::Render('users/errors', 'include', 'auth_fb_code');
        }
    }
    
    public function LoginGoogle() {
        if (!(int) APP::Module('Registry')->Get('module_users_login_service')) APP::Render('users/errors', 'include', 'auth_service');
        
        if (isset(APP::Module('Routing')->get['code'])) {
            $google_auth = APP::Module('Registry')->Get([
                'module_users_social_auth_google_id',
                'module_users_social_auth_google_key'
            ]);

            $curl = curl_init();
            
            curl_setopt($curl, CURLOPT_URL, 'https://accounts.google.com/o/oauth2/token');
            curl_setopt($curl, CURLOPT_POST, 1);
            curl_setopt($curl, CURLOPT_POSTFIELDS, urldecode(http_build_query(['client_id' => $google_auth['module_users_social_auth_google_id'], 'client_secret' => $google_auth['module_users_social_auth_google_key'], 'code' => APP::Module('Routing')->get['code'], 'redirect_uri' => APP::Module('Routing')->root . 'users/login/google', 'grant_type' => 'authorization_code'])));
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
            
            $google_result = json_decode(curl_exec($curl), true);
            
            curl_close($curl);

            if (isset($google_result['access_token'])) {
                $google_user = json_decode(file_get_contents('https://www.googleapis.com/oauth2/v1/userinfo?' . urldecode(http_build_query(['access_token' => $google_result['access_token']]))), true);

                if (isset($google_user['id'])) {
                    if ($user_id = APP::Module('DB')->Select(
                        $this->conf['connection'], ['fetchColumn', 0], 
                        ['user_id'], 'social_accounts', 
                        [
                            ['network', '=', 'google', PDO::PARAM_STR], 
                            ['extra', '=', $google_user['id'], PDO::PARAM_STR]
                        ]
                    )) {
                        $this->user = $this->Auth($user_id, true, true);
                    } else {
                        if (isset($google_user['email'])) {
                            if ($user_id = APP::Module('DB')->Select(
                                $this->conf['connection'], ['fetchColumn', 0], 
                                ['id'], 'users', [['email', '=', $google_user['email'], PDO::PARAM_STR]]
                            )) {
                                APP::Module('DB')->Insert(
                                    $this->conf['connection'], ' social_accounts',
                                    [
                                        'id' => 'NULL',
                                        'user_id' => [$user_id, PDO::PARAM_INT],
                                        'network' => '"google"',
                                        'extra' => [$google_user['id'], PDO::PARAM_STR],
                                        'up_date' => 'NOW()',
                                    ]
                                );

                                $this->user = $this->Auth($user_id, true, true);
                            } else {
                                $password = $this->GeneratePassword((int) APP::Module('Registry')->Get('module_users_gen_pass_length'));
                                $user_id = $this->Register($google_user['email'], $password, 'user');
                                $this->user = $this->Auth($user_id, true, true);

                                APP::Module('DB')->Insert(
                                    $this->conf['connection'], ' social_accounts',
                                    [
                                        'id' => 'NULL',
                                        'user_id' => [$user_id, PDO::PARAM_INT],
                                        'network' => '"google"',
                                        'extra' => [$google_user['id'], PDO::PARAM_STR],
                                        'up_date' => 'NOW()',
                                    ]
                                );

                                $letter = APP::Module('DB')->Select(
                                    APP::Module('Mail')->conf['connection'], 
                                    ['fetch', PDO::FETCH_ASSOC], 
                                    [
                                        'letters.subject', 
                                        'letters.html', 
                                        'letters.plaintext', 
                                        'letters.list_id',
                                        'senders.name',
                                        'senders.email'
                                    ], 
                                    'letters', 
                                    [['letters.id', '=', APP::Module('Registry')->Get('module_users_register_letter'), PDO::PARAM_INT]],
                                    ['join/senders' => [['senders.id','=','letters.sender_id']]]
                                );

                                $login_details = [
                                    'email' => $google_user['email'],
                                    'password' => $password,
                                ];

                                APP::Module('Mail')->Send(
                                    [$letter['email'], $letter['name']], $google_user['email'], $letter['subject'], 
                                    [
                                        APP::Render($letter['html'], 'eval', $login_details),
                                        APP::Render($letter['plaintext'], 'eval', $login_details)
                                    ],
                                    ['List-id' => $letter['list_id']]
                                );
                            }
                        } else {
                            APP::Render('users/errors', 'include', 'auth_google_email');
                        }
                    }
                } else {
                    APP::Render('users/errors', 'include', 'auth_google_id');
                }

                header('Location: ' . APP::Module('Crypt')->Decode(json_decode(APP::Module('Crypt')->SafeB64Decode(APP::Module('Routing')->get['state']), 1)['return']));
                exit;
            } else {
                APP::Render('users/errors', 'include', 'auth_google_access_token');
            }
        } else {
            APP::Render('users/errors', 'include', 'auth_google_code');
        }
    }
    
    public function LoginYA() {  
        if (!(int) APP::Module('Registry')->Get('module_users_login_service')) APP::Render('users/errors', 'include', 'auth_service');
        
        if (isset(APP::Module('Routing')->get['code'])) {
            $ya_auth = APP::Module('Registry')->Get([
                'module_users_social_auth_ya_id',
                'module_users_social_auth_ya_key'
            ]);

            $curl = curl_init();
            
            curl_setopt($curl, CURLOPT_URL, 'https://oauth.yandex.ru/token');
            curl_setopt($curl, CURLOPT_POST, 1);
            curl_setopt($curl, CURLOPT_POSTFIELDS, urldecode(http_build_query(['client_id' => $ya_auth['module_users_social_auth_ya_id'], 'client_secret' => $ya_auth['module_users_social_auth_ya_key'], 'code' => APP::Module('Routing')->get['code'], 'redirect_uri' => APP::Module('Routing')->root . 'users/login/ya', 'grant_type' => 'authorization_code'])));
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
            
            $ya_result = json_decode(curl_exec($curl), true);
            
            curl_close($curl);

            if (isset($ya_result['access_token'])) {
                $ya_user = json_decode(file_get_contents('https://login.yandex.ru/info?' . urldecode(http_build_query(['oauth_token' => $ya_result['access_token'], 'format' => 'json']))), true);

                if (isset($ya_user['id'])) {
                    if ($user_id = APP::Module('DB')->Select(
                        $this->conf['connection'], ['fetchColumn', 0], 
                        ['user_id'], 'social_accounts', 
                        [
                            ['network', '=', 'ya', PDO::PARAM_STR], 
                            ['extra', '=', $ya_user['id'], PDO::PARAM_STR]
                        ]
                    )) {
                        $this->user = $this->Auth($user_id, true, true);
                    } else {
                        if (isset($ya_user['default_email'])) {
                            if ($user_id = APP::Module('DB')->Select(
                                $this->conf['connection'], ['fetchColumn', 0], 
                                ['id'], 'users', [['email', '=', $ya_user['default_email'], PDO::PARAM_STR]]
                            )) {
                                APP::Module('DB')->Insert(
                                    $this->conf['connection'], ' social_accounts',
                                    [
                                        'id' => 'NULL',
                                        'user_id' => [$user_id, PDO::PARAM_INT],
                                        'network' => '"ya"',
                                        'extra' => [$ya_user['id'], PDO::PARAM_STR],
                                        'up_date' => 'NOW()',
                                    ]
                                );

                                $this->user = $this->Auth($user_id, true, true);
                            } else {
                                $password = $this->GeneratePassword((int) APP::Module('Registry')->Get('module_users_gen_pass_length'));
                                $user_id = $this->Register($ya_user['default_email'], $password, 'user');
                                $this->user = $this->Auth($user_id, true, true);

                                APP::Module('DB')->Insert(
                                    $this->conf['connection'], ' social_accounts',
                                    [
                                        'id' => 'NULL',
                                        'user_id' => [$user_id, PDO::PARAM_INT],
                                        'network' => '"ya"',
                                        'extra' => [$ya_user['id'], PDO::PARAM_STR],
                                        'up_date' => 'NOW()',
                                    ]
                                );

                                $letter = APP::Module('DB')->Select(
                                    APP::Module('Mail')->conf['connection'], 
                                    ['fetch', PDO::FETCH_ASSOC], 
                                    [
                                        'letters.subject', 
                                        'letters.html', 
                                        'letters.plaintext', 
                                        'letters.list_id',
                                        'senders.name',
                                        'senders.email'
                                    ], 
                                    'letters', 
                                    [['letters.id', '=', APP::Module('Registry')->Get('module_users_register_letter'), PDO::PARAM_INT]],
                                    ['join/senders' => [['senders.id','=','letters.sender_id']]]
                                );

                                $login_details = [
                                    'email' => $ya_user['default_email'],
                                    'password' => $password,
                                ];

                                APP::Module('Mail')->Send(
                                    [$letter['email'], $letter['name']], $ya_user['default_email'], $letter['subject'], 
                                    [
                                        APP::Render($letter['html'], 'eval', $login_details),
                                        APP::Render($letter['plaintext'], 'eval', $login_details)
                                    ],
                                    ['List-id' => $letter['list_id']]
                                );
                            }
                        } else {
                            APP::Render('users/errors', 'include', 'auth_ya_email');
                        }
                    }
                } else {
                    APP::Render('users/errors', 'include', 'auth_ya_id');
                }

                header('Location: ' . APP::Module('Crypt')->Decode(json_decode(APP::Module('Crypt')->SafeB64Decode(APP::Module('Routing')->get['state']), 1)['return']));
                exit;
            } else {
                APP::Render('users/errors', 'include', 'auth_ya_access_token');
            }
        } else {
            APP::Render('users/errors', 'include', 'auth_ya_code');
        }
    }

}