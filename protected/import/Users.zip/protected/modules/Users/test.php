<?
include_once 'init.php';
use PHPUnit\Framework\TestCase;

class UsersTest extends TestCase {}