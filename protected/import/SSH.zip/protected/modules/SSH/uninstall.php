<?
APP::Module('Registry')->Delete([['item', '=', 'module_ssh_connection', PDO::PARAM_STR]]);