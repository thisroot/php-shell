<?
use PHPUnit\Framework\TestCase;

class SSHTest extends TestCase {}