<?
use PHPUnit\Framework\TestCase;

class RoutingTest extends TestCase {}